# Function to save a list of product dictionaries to file
def saveProductList(filePath, productList):
    with open(filePath, "w") as f:
        for product in productList:
            line = f"{product['name']},{product['brand']},{product['quantity']},{product['price']},{product['country']}\n"
            f.write(line)

def generateInvoice(filename, content):
    with open(filename, 'w') as f:
        f.write(content)