import datetime
from write import generateInvoice


def restock(productList):
    while True:
        supplier_name = input("\nEnter supplier/vendor name: ")
        if supplier_name.strip() == "":
            print('\nSupplier name cannot be empty.')
            continue;
        break;
        
    total = 0
    invoice_lines = []
    while True:
        product_name = input("\nEnter product name to restock (or 'done' to finish): ")
        if product_name.strip() == "":
            print('\nProduct name cannot be empty.')
            continue
        
        if product_name.lower() == 'done':
            break
        found = False
        for product in productList:
            if product['name'].lower() == product_name.lower():
                found = True
                try:
                    quantity = int(input("\nEnter quantity to add: "))
                    if quantity <= 0:
                        print("Error: Quantity must be greater than 0.")
                        break

                    new_price = int(input("\nEnter cost price per item: "))
                    if new_price <= 0:
                        print("Error: Cost price must be greater than 0.")
                        break
                except ValueError:
                    print("Invalid input. Please enter valid integers.")
                    break

                product['quantity'] += quantity
                product['price'] = new_price 
                item_total = quantity * new_price
                total += item_total
                invoice_lines.append(f"{product['name']} ({product['brand']}) - Qty: {quantity} - Rs. {new_price} each - Rs. {item_total}")
                break

        if not found:
            print("Product not found. Adding it as a new product.")
            while True:
                brand = input("Enter brand name: ").strip()
                if brand == "":
                    print("Brand name cannot be empty.")
                else:
                    break

            while True:
                try:
                    quantity_input = input("Enter quantity to add: ").strip()
                    if quantity_input == "":
                        print("Quantity cannot be empty.")
                        continue
                    quantity = int(quantity_input)
                    if quantity <= 0:
                        print("Quantity must be greater than 0.")
                        continue
                    break
                except ValueError:
                    print("Invalid quantity. Please enter a valid number.")

            while True:
                try:
                    price_input = input("Enter cost price per item: ").strip()
                    if price_input == "":
                        print("Price cannot be empty.")
                        continue
                    price = int(price_input)
                    if price <= 0:
                        print("Price must be greater than 0.")
                        continue
                    break
                except ValueError:
                    print("Invalid price. Please enter a valid number.")

            while True:
                country = input("Enter country of origin: ").strip()
                if country == "":
                    print("Country cannot be empty.")
                else:
                    break

            new_product = {
                "name": product_name,
                "brand": brand,
                "quantity": quantity,
                "price": price,
                "country": country
            }
            productList.append(new_product)
            item_total = quantity * price
            total += item_total
            invoice_lines.append(f"{product_name} ({brand}) - Qty: {quantity} - Rs. {price} each - Rs. {item_total}")
            print(f"New product '{product_name}' added successfully.")

    if invoice_lines:
        invoice = f"Restock Invoice\n\nSupplier: {supplier_name}\nDate: {datetime.datetime.now()}\n\n"
        invoice += "Items:\n\n"
        invoice += "\n".join(invoice_lines)
        invoice += f"\n\nTotal: Rs. {total}"
        filename = f"restock_invoice_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        generateInvoice(filename, invoice)
        print("Restock complete. Invoice generated.")
    else:
        print("No items restocked. Invoice not generated.")

def processSale(productList):
    customer_name = input("\nEnter customer name: ")
    total = 0
    invoice_lines = []

    while True:
        product_name = input("\nEnter product name (or 'done' to finish): ")
        if product_name.lower() == 'done':
            break
        found = False
        for product in productList:
            if product['name'].lower() == product_name.lower():
                found = True
                try:
                    quantity = int(input(f"\nEnter quantity for {product_name}: "))
                    if quantity <= 0:
                        print("Quantity must be greater than 0.")
                        break
                except ValueError:
                    print("Invalid quantity. Please enter a valid number.")
                    break
                max_qty = 0
                for q in range(1, product['quantity'] + 1):
                    if q + (q // 3) > product['quantity']:
                        break
                    max_qty = q

                if quantity > max_qty:
                    print(f"Cannot sell {quantity} units. Max you can buy is {max_qty} (including free items it will be {max_qty + (max_qty // 3)}).")
                    break
                free_items = quantity // 3
                total_items = quantity + free_items
                product['quantity'] -= total_items
                item_total = quantity * (product['price'] * 2)
                total += item_total
                invoice_lines.append(f"{product['name']} ({product['brand']}) - Qty: {quantity} (+{free_items} free) - Rs. {item_total}")
                break
        if not found:
            print("Product not found.")

    if invoice_lines:
        invoice = f"Sales Invoice\n\nCustomer: {customer_name}\nDate: {datetime.datetime.now()}\n\n"
        invoice += "Items:\n\n"
        invoice += "\n".join(invoice_lines)
        invoice += f"\n\nTotal: Rs. {total}"
        filename = f"sales_invoice_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        generateInvoice(filename, invoice)
        print("Sale complete. Invoice generated.")
    else:
        print("No items sold. Invoice not generated.")


