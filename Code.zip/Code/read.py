# Function to validate user input
def inputValidation(number):
    if number == '':
        return [False, "\nError: Empty value. Please, enter some value."]
    try:
        value = int(number)
    except:
        return [False, "\nError: Only numeric value is allowed."]
    if value < 0:
        return [False, "\nError: Enter positive integer."]
    if value not in [0, 1, 2, 3]:
        return [False, "\nError: Please read the instruction carefully."]
    return [True, 'Success']

def prepareProductList(filePath):
    with open(filePath, "r") as f:
        productLines = f.readlines()
    productList = [] # create empty list
    for product in productLines:
        values = product.strip().split(',')
        productDictonary = {
            "name": values[0],
            "brand": values[1],
            "quantity": int(values[2]),
            "price": int(values[3]),   
            "country": values[4]
        }
        productList.append(productDictonary)
    return productList



def displayProducts(productList):
    print("-" * 50)
    for product in productList:
        print(f"Name: {product['name']}")
        print(f"Brand: {product['brand']}")
        print(f"Quantity: {product['quantity']}")
        print(f"Price: {product['price'] * 200}")
        print(f"Country: {product['country']}")
        print("-" * 50)

