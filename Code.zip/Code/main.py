# import necessary function
from read import inputValidation, prepareProductList,  displayProducts
from operations import processSale, restock
from write import saveProductList
import os

productFilePath = "products.txt"
print("Welcome to WeCare")

flag = True
while flag:
    # Display menu options
    print("""\nPlease, enter 
            0: to exit the program.
            1: List the products.
            2: Process Sale
            3: Restock Products
        """)
    while True:
        number = input("\nEnter your choice: ")
        isValidInput = inputValidation(number)
        if not isValidInput[0]:
            print(isValidInput[1])
            continue
        else:
            break

    choice = int(number)
    # Handle each menu option
    if choice == 0:
        print("Exiting the program.")
        flag = False
    elif choice == 1:
        allProducts = prepareProductList(productFilePath)
        displayProducts(allProducts)
    elif choice == 2:
        allProducts = prepareProductList(productFilePath)
        processSale(allProducts)
        saveProductList(productFilePath, allProducts)
    elif choice == 3:
        allProducts = prepareProductList(productFilePath)
        restock(allProducts)
        saveProductList(productFilePath, allProducts)
    else:
        print("Invalid option. Try again.")

